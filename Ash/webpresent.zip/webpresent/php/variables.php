<?php

$ds = "/";
$uploadDir = $_SERVER['DOCUMENT_ROOT'].'/webpresent/Presentation';
$fileName = $_SERVER['DOCUMENT_ROOT'].'/webpresent/presentationOrder.txt';


?>