var CONFIG = {
 //'relay': 'ws://192.168.0.13:3000/relay',
 //'relay': 'ws://goo.scem.ws:3000/relay',
 //'relay': 'ws://192.168.1.2:3000/relay',
 //'ws': 'ws://137.154.151.239:3000/relay',
 //'ws': 'ws://10.237.10.1:3000/relay',
 //'relay': 'ws://10.237.10.103:3000/relay',
 //'relay': 'ws://192.168.0.13:3000/relay',
 'relay': 'ws://10.103.246.211:3000/relay',
 //'media': 'media/'
};
